import api from './api';

export const fileService = {
  // Get all files
  getAllFiles: async (filters = {}) => {
    const response = await api.get('/files', { params: filters });
    return response.data;
  },

  // Get user's files
  getMyFiles: async () => {
    const response = await api.get('/files/my-files');
    return response.data;
  },

  // Upload file
  uploadFile: async (formData) => {
    const response = await api.post('/files/upload', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
    return response.data;
  },

  // Download file
  downloadFile: async (fileId) => {
    const response = await api.get(`/files/download/${fileId}`, {
      responseType: 'blob',
    });
    return response.data;
  },

  // Delete file
  deleteFile: async (fileId) => {
    const response = await api.delete(`/files/${fileId}`);
    return response.data;
  },

  // Update file position (for canvas)
  updateFilePosition: async (fileId, position) => {
    const response = await api.patch(`/files/${fileId}/position`, position);
    return response.data;
  },
};