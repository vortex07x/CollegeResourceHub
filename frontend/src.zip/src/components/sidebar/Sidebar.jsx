import { Grid3x3, Upload, Move, ChevronRight, ChevronDown, ChevronUp, X, SlidersHorizontal } from 'lucide-react';
import { useState } from 'react';
import useFileStore from '../../store/useFileStore';

const Sidebar = () => {
  const { currentMode, setMode, filters, setFilters } = useFileStore();
  const [isOpen, setIsOpen] = useState(false);
  const [expandedSections, setExpandedSections] = useState({
    fileType: true,
    category: true,
    uploadDate: false,
  });

  const modes = [
    { id: 'browse', label: 'Browse', icon: Grid3x3, color: 'purple' },
    { id: 'upload', label: 'Upload', icon: Upload, color: 'blue' },
    { id: 'organize', label: 'Organize', icon: Move, color: 'green' },
  ];

  const fileTypes = [
    { value: 'all', label: 'All Files', count: 24 },
    { value: 'pdf', label: 'PDF', count: 18 },
    { value: 'docx', label: 'DOCX', count: 6 },
  ];

  const categories = [
    { value: 'all', label: 'All' },
    { value: 'assignment', label: 'Assignments' },
    { value: 'question-paper', label: 'Question Papers' },
    { value: 'syllabus', label: 'Syllabus' },
    { value: 'notes', label: 'Notes' },
  ];

  const dateRanges = [
    { value: 'all', label: 'All Time' },
    { value: 'week', label: 'This Week' },
    { value: 'month', label: 'This Month' },
    { value: 'year', label: 'This Year' },
  ];

  const toggleSection = (section) => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }));
  };

  const handleModeChange = (modeId) => {
    setMode(modeId);
    setTimeout(() => setIsOpen(false), 200);
  };

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="fixed top-24 left-8 z-[96] w-12 h-12 bg-gradient-to-br from-purple-500 via-purple-600 to-blue-600 rounded-xl flex items-center justify-center text-white shadow-xl shadow-purple-500/30 hover:shadow-2xl hover:shadow-purple-500/40 hover:scale-110 transition-all duration-300"
        title="Open Filters"
      >
        <SlidersHorizontal size={20} />
      </button>
    );
  }

  return (
    <>
      {/* Overlay */}
      <div 
        className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[97] animate-fadeIn"
        onClick={() => setIsOpen(false)}
      />

      {/* Floating Sidebar */}
      <div className="fixed top-24 left-8 bottom-8 w-80 bg-gradient-to-br from-[#0A0A0A] to-[#121212] backdrop-blur-xl border border-white/10 rounded-2xl shadow-2xl z-[98] flex flex-col overflow-hidden animate-slideInLeft">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-white/10">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-blue-500 rounded-lg flex items-center justify-center">
              <SlidersHorizontal size={16} className="text-white" />
            </div>
            <h2 className="text-lg font-bold text-white">Filters</h2>
          </div>
          <button
            onClick={() => setIsOpen(false)}
            className="w-8 h-8 flex items-center justify-center text-gray-400 hover:text-white hover:bg-white/10 rounded-lg transition-all"
          >
            <X size={18} />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-5 space-y-6 custom-scrollbar">
          {/* Mode Selector */}
          <div>
            <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3">
              Mode
            </h3>
            <div className="space-y-2">
              {modes.map((modeItem) => {
                const Icon = modeItem.icon;
                const isActive = currentMode === modeItem.id;
                
                return (
                  <button
                    key={modeItem.id}
                    onClick={() => handleModeChange(modeItem.id)}
                    className={`w-full p-3 rounded-xl flex items-center gap-3 transition-all duration-200 ${
                      isActive
                        ? 'bg-gradient-to-r from-purple-500 to-blue-500 text-white shadow-lg shadow-purple-500/25'
                        : 'bg-white/5 text-gray-400 hover:bg-white/10 hover:text-white'
                    }`}
                  >
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                      isActive ? 'bg-white/20' : 'bg-white/10'
                    }`}>
                      <Icon size={16} />
                    </div>
                    <span className="text-sm font-semibold">{modeItem.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="h-px bg-white/10" />

          {/* File Type Filter */}
          <div>
            <button
              onClick={() => toggleSection('fileType')}
              className="w-full flex items-center justify-between text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3 hover:text-gray-300 transition-colors"
            >
              <span>File Type</span>
              {expandedSections.fileType ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
            </button>
            {expandedSections.fileType && (
              <div className="space-y-1.5 animate-fadeIn">
                {fileTypes.map((type) => {
                  const isActive = filters.fileType === type.value;
                  return (
                    <button
                      key={type.value}
                      onClick={() => setFilters({ ...filters, fileType: type.value })}
                      className={`w-full px-3 py-2.5 rounded-lg text-left text-sm transition-all flex items-center justify-between ${
                        isActive
                          ? 'bg-purple-500/15 text-purple-400 font-medium'
                          : 'text-gray-400 hover:bg-white/5 hover:text-white'
                      }`}
                    >
                      <span>{type.label}</span>
                      <span className={`text-xs px-2 py-0.5 rounded-full ${
                        isActive ? 'bg-purple-500/20 text-purple-300' : 'bg-white/5 text-gray-500'
                      }`}>
                        {type.count}
                      </span>
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* Category Filter */}
          <div>
            <button
              onClick={() => toggleSection('category')}
              className="w-full flex items-center justify-between text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3 hover:text-gray-300 transition-colors"
            >
              <span>Category</span>
              {expandedSections.category ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
            </button>
            {expandedSections.category && (
              <div className="space-y-1.5 animate-fadeIn">
                {categories.map((category) => {
                  const isActive = filters.category === category.value;
                  return (
                    <button
                      key={category.value}
                      onClick={() => setFilters({ ...filters, category: category.value })}
                      className={`w-full px-3 py-2.5 rounded-lg text-left text-sm transition-all ${
                        isActive
                          ? 'bg-purple-500/15 text-purple-400 font-medium'
                          : 'text-gray-400 hover:bg-white/5 hover:text-white'
                      }`}
                    >
                      {category.label}
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* Date Range Filter */}
          <div>
            <button
              onClick={() => toggleSection('uploadDate')}
              className="w-full flex items-center justify-between text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3 hover:text-gray-300 transition-colors"
            >
              <span>Upload Date</span>
              {expandedSections.uploadDate ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
            </button>
            {expandedSections.uploadDate && (
              <div className="space-y-1.5 animate-fadeIn">
                {dateRanges.map((range) => {
                  const isActive = filters.dateRange === range.value;
                  return (
                    <button
                      key={range.value}
                      onClick={() => setFilters({ ...filters, dateRange: range.value })}
                      className={`w-full px-3 py-2.5 rounded-lg text-left text-sm transition-all ${
                        isActive
                          ? 'bg-purple-500/15 text-purple-400 font-medium'
                          : 'text-gray-400 hover:bg-white/5 hover:text-white'
                      }`}
                    >
                      {range.label}
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>

      <style jsx>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(139, 92, 246, 0.3);
          border-radius: 3px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: rgba(139, 92, 246, 0.5);
        }
        
        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        
        @keyframes slideInLeft {
          from {
            opacity: 0;
            transform: translateX(-100%);
          }
          to {
            opacity: 1;
            transform: translateX(0);
          }
        }
        
        .animate-fadeIn {
          animation: fadeIn 0.2s ease-out;
        }
        
        .animate-slideInLeft {
          animation: slideInLeft 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
        }
      `}</style>
    </>
  );
};

export default Sidebar;