import { Link, useLocation } from 'react-router-dom';
import { Home, FolderOpen, FileText, User, LogOut, Menu, X } from 'lucide-react';
import { useState } from 'react';
import useAuthStore from '../../store/useAuthStore';

const Navbar = () => {
  const location = useLocation();
  const { isAuthenticated, user, logout } = useAuthStore();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { path: '/', label: 'Home', icon: Home },
    { path: '/browse', label: 'Browse Files', icon: FolderOpen },
    { path: '/my-files', label: 'My Files', icon: FileText },
  ];

  const isActive = (path) => location.pathname === path;

  const handleLogout = async () => {
    await logout();
    setMobileMenuOpen(false);
  };

  return (
    <nav className="sticky top-0 left-0 right-0 z-[1000] bg-black/95 border-b border-white/10 backdrop-blur-md">
      <div className="container mx-auto px-4 sm:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link 
            to="/" 
            className="flex items-center gap-2 text-2xl font-bold text-white tracking-tight hover:text-purple-400 transition-colors duration-300"
          >
            <span className="text-2xl">📚</span>
            <span className="hidden sm:inline">College Hub</span>
          </Link>

          {/* Desktop Navigation Links */}
          <div className="hidden md:flex items-center space-x-8">
            {navLinks.map((link) => {
              const Icon = link.icon;
              const active = isActive(link.path);
              
              return (
                <Link
                  key={link.path}
                  to={link.path}
                  className="relative flex items-center gap-2 text-base font-medium transition-all duration-300 group"
                >
                  <Icon size={20} className={active ? 'text-white' : 'text-gray-400 group-hover:text-white'} />
                  <span className={active ? 'text-white' : 'text-gray-400 group-hover:text-white'}>
                    {link.label}
                  </span>
                  
                  {/* Active Indicator */}
                  {active && (
                    <span className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-1 h-1 bg-purple-500 rounded-full" />
                  )}
                  
                  {/* Hover Underline */}
                  {!active && (
                    <span className="absolute -bottom-2 left-0 w-0 h-0.5 bg-purple-500 transition-all duration-300 group-hover:w-full" />
                  )}
                </Link>
              );
            })}
          </div>

          {/* Desktop User Section */}
          <div className="hidden md:flex items-center gap-4">
            {isAuthenticated ? (
              <>
                <Link
                  to="/profile"
                  className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors duration-300"
                >
                  <User size={20} />
                  <span className="font-medium">{user?.name || 'Profile'}</span>
                </Link>
                <button
                  onClick={handleLogout}
                  className="flex items-center gap-2 text-red-500 hover:text-red-400 transition-all duration-300 hover:scale-105"
                >
                  <LogOut size={20} />
                  <span className="font-medium">Logout</span>
                </button>
              </>
            ) : (
              <Link
                to="/login"
                className="px-8 py-3 bg-white text-black rounded-full font-semibold hover:scale-105 hover:shadow-[0_4px_20px_rgba(255,255,255,0.2)] transition-all duration-300 flex items-center gap-2"
              >
                Login
                <span className="text-sm">→</span>
              </Link>
            )}
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden w-10 h-10 flex items-center justify-center text-white hover:text-purple-400 transition-colors"
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <div
        className={`md:hidden fixed top-16 left-0 right-0 bg-[#0A0A0A] border-b border-white/10 transition-transform duration-300 ease-in-out ${
          mobileMenuOpen ? 'translate-y-0' : '-translate-y-full'
        }`}
      >
        <div className="container mx-auto px-4 py-6 space-y-4">
          {/* Mobile Nav Links */}
          {navLinks.map((link) => {
            const Icon = link.icon;
            const active = isActive(link.path);
            
            return (
              <Link
                key={link.path}
                to={link.path}
                onClick={() => setMobileMenuOpen(false)}
                className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-300 ${
                  active
                    ? 'bg-gradient-to-r from-purple-500 to-blue-500 text-white shadow-[0_4px_12px_rgba(139,92,246,0.3)]'
                    : 'text-gray-400 hover:bg-white/5 hover:text-white'
                }`}
              >
                <Icon size={20} />
                <span className="font-medium">{link.label}</span>
              </Link>
            );
          })}

          {/* Mobile User Section */}
          <div className="pt-4 border-t border-white/10 space-y-4">
            {isAuthenticated ? (
              <>
                <Link
                  to="/profile"
                  onClick={() => setMobileMenuOpen(false)}
                  className="flex items-center gap-3 px-4 py-3 text-gray-400 hover:bg-white/5 hover:text-white rounded-lg transition-all duration-300"
                >
                  <User size={20} />
                  <span className="font-medium">{user?.name || 'Profile'}</span>
                </Link>
                <button
                  onClick={handleLogout}
                  className="w-full flex items-center gap-3 px-4 py-3 text-red-500 hover:bg-red-500/10 rounded-lg transition-all duration-300"
                >
                  <LogOut size={20} />
                  <span className="font-medium">Logout</span>
                </button>
              </>
            ) : (
              <Link
                to="/login"
                onClick={() => setMobileMenuOpen(false)}
                className="block w-full px-8 py-3 bg-white text-black text-center rounded-full font-semibold hover:scale-105 transition-all duration-300"
              >
                Login
              </Link>
            )}
          </div>
        </div>
      </div>

      {/* Mobile Menu Overlay */}
      {mobileMenuOpen && (
        <div
          onClick={() => setMobileMenuOpen(false)}
          className="md:hidden fixed inset-0 top-16 bg-black/70 backdrop-blur-sm z-[-1]"
        />
      )}
    </nav>
  );
};

export default Navbar;