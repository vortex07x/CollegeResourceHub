import { create } from 'zustand';

const useFileStore = create((set) => ({
  files: [],
  currentMode: 'browse', // 'browse', 'upload', 'organize'
  filters: {
    fileType: 'all',
    category: 'all',
    dateRange: 'all',
  },
  setFiles: (files) => set({ files }),
  addFile: (file) => set((state) => ({ files: [...state.files, file] })),
  removeFile: (fileId) =>
    set((state) => ({ files: state.files.filter((f) => f.id !== fileId) })),
  setMode: (mode) => set({ currentMode: mode }),
  setFilters: (filters) => set({ filters }),
}));

export default useFileStore;