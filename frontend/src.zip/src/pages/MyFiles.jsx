import { useState } from 'react';
import { Upload, FileText, Eye, HardDrive, Grid3x3, List, Download, Edit2, Trash2, MoreVertical } from 'lucide-react';

const MyFiles = () => {
  const [viewMode, setViewMode] = useState('grid'); // 'grid' or 'list'
  const [files, setFiles] = useState([
    {
      id: 1,
      name: 'Data Structures Assignment.pdf',
      type: 'PDF',
      size: '2.4 MB',
      uploadDate: '2024-09-27',
      views: 45,
      category: 'Assignment',
    },
    {
      id: 2,
      name: 'Algorithm Analysis Notes.docx',
      type: 'DOCX',
      size: '1.8 MB',
      uploadDate: '2024-09-24',
      views: 32,
      category: 'Notes',
    },
    {
      id: 3,
      name: 'Database Management Syllabus.pdf',
      type: 'PDF',
      size: '856 KB',
      uploadDate: '2024-09-22',
      views: 78,
      category: 'Syllabus',
    },
    {
      id: 4,
      name: 'Web Development Question Paper.pdf',
      type: 'PDF',
      size: '1.2 MB',
      uploadDate: '2024-09-26',
      views: 56,
      category: 'Question Paper',
    },
    {
      id: 5,
      name: 'Machine Learning Project.docx',
      type: 'DOCX',
      size: '3.1 MB',
      uploadDate: '2024-09-28',
      views: 23,
      category: 'Assignment',
    },
    {
      id: 6,
      name: 'Operating Systems Notes.pdf',
      type: 'PDF',
      size: '2.7 MB',
      uploadDate: '2024-09-25',
      views: 67,
      category: 'Notes',
    },
  ]);

  const stats = [
    { icon: FileText, label: 'Total Files', value: files.length, color: 'text-purple-500' },
    { icon: Upload, label: 'Uploads This Month', value: 8, color: 'text-blue-500' },
    { icon: Eye, label: 'Total Views', value: '1,247', color: 'text-green-500' },
    { icon: HardDrive, label: 'Storage Used', value: '156 MB', color: 'text-orange-500' },
  ];

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now - date);
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) return 'Today';
    if (diffDays === 1) return 'Yesterday';
    if (diffDays < 7) return `${diffDays} days ago`;
    if (diffDays < 30) return `${Math.floor(diffDays / 7)} weeks ago`;
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  };

  const getFileIcon = (type) => {
    return type === 'PDF' ? '📄' : '📝';
  };

  const handleDelete = (fileId) => {
    if (confirm('Are you sure you want to delete this file?')) {
      setFiles(files.filter(f => f.id !== fileId));
    }
  };

  return (
    <div className="min-h-screen bg-black pt-20 px-8 pb-16">
      <div className="max-w-7xl mx-auto">
        {/* Page Header */}
        <div className="flex items-center justify-between mb-12">
          <h1 className="text-4xl font-bold text-white">My Files</h1>
          <button className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-purple-500 to-blue-500 text-white rounded-xl font-semibold shadow-lg shadow-purple-500/30 hover:scale-105 transition-transform">
            <Upload size={16} />
            Upload File
          </button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {stats.map((stat, index) => (
            <div
              key={index}
              className="bg-[#0A0A0A] border border-white/10 rounded-xl p-6 hover:border-purple-500/30 transition-colors"
            >
              <stat.icon size={32} className={`${stat.color} mb-3`} />
              <div className="text-4xl font-bold text-white mb-1">{stat.value}</div>
              <div className="text-sm text-gray-400">{stat.label}</div>
            </div>
          ))}
        </div>

        {/* View Toggle */}
        <div className="flex items-center gap-3 mb-6">
          <button
            onClick={() => setViewMode('grid')}
            className={`w-10 h-10 flex items-center justify-center border rounded-lg transition-all ${
              viewMode === 'grid'
                ? 'bg-purple-500 border-purple-500 text-white'
                : 'bg-[#1A1A1A] border-white/10 text-gray-400 hover:bg-white/5'
            }`}
          >
            <Grid3x3 size={18} />
          </button>
          <button
            onClick={() => setViewMode('list')}
            className={`w-10 h-10 flex items-center justify-center border rounded-lg transition-all ${
              viewMode === 'list'
                ? 'bg-purple-500 border-purple-500 text-white'
                : 'bg-[#1A1A1A] border-white/10 text-gray-400 hover:bg-white/5'
            }`}
          >
            <List size={18} />
          </button>
        </div>

        {/* Grid View */}
        {viewMode === 'grid' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {files.map((file) => (
              <div
                key={file.id}
                className="bg-[#0A0A0A] border border-white/10 rounded-xl p-5 hover:border-purple-500 hover:-translate-y-1 transition-all duration-300 group"
              >
                {/* File Icon */}
                <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-blue-500 rounded-xl flex items-center justify-center mb-4">
                  <span className="text-3xl">{getFileIcon(file.type)}</span>
                </div>

                {/* File Name */}
                <h3 className="text-white font-semibold text-base mb-2 line-clamp-2 min-h-[3rem]">
                  {file.name}
                </h3>

                {/* File Meta */}
                <div className="space-y-1 mb-4 text-xs text-gray-500">
                  <div className="flex items-center gap-2">
                    <span>📄</span>
                    <span>{file.type}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span>💾</span>
                    <span>{file.size}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span>📅</span>
                    <span>{formatDate(file.uploadDate)}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span>👁️</span>
                    <span>{file.views} views</span>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex gap-2">
                  <button className="flex-1 py-2 bg-gradient-to-r from-purple-500 to-blue-500 text-white text-xs font-semibold rounded-lg hover:opacity-90 transition-opacity flex items-center justify-center gap-1">
                    <Download size={14} />
                    Download
                  </button>
                  <button className="w-9 h-9 bg-white/5 border border-white/10 text-white rounded-lg hover:bg-white/10 transition-colors flex items-center justify-center">
                    <Edit2 size={14} />
                  </button>
                  <button
                    onClick={() => handleDelete(file.id)}
                    className="w-9 h-9 bg-white/5 border border-white/10 text-red-400 rounded-lg hover:bg-red-500/10 hover:border-red-500/30 transition-colors flex items-center justify-center"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* List View */}
        {viewMode === 'list' && (
          <div className="bg-[#0A0A0A] border border-white/10 rounded-xl overflow-hidden">
            {/* Table Header */}
            <div className="bg-[#1A1A1A] px-6 py-4 grid grid-cols-[2fr_1fr_1fr_1fr_1fr_120px] gap-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">
              <div>File Name</div>
              <div>Type</div>
              <div>Size</div>
              <div>Upload Date</div>
              <div>Views</div>
              <div className="text-center">Actions</div>
            </div>

            {/* Table Rows */}
            {files.map((file, index) => (
              <div
                key={file.id}
                className={`px-6 py-4 grid grid-cols-[2fr_1fr_1fr_1fr_1fr_120px] gap-4 items-center hover:bg-white/[0.02] transition-colors ${
                  index !== files.length - 1 ? 'border-b border-white/5' : ''
                }`}
              >
                {/* File Name with Icon */}
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-blue-500 rounded-lg flex items-center justify-center flex-shrink-0">
                    <span className="text-lg">{getFileIcon(file.type)}</span>
                  </div>
                  <span className="text-white font-medium text-sm truncate">{file.name}</span>
                </div>

                {/* Type */}
                <div className="text-gray-400 text-sm">{file.type}</div>

                {/* Size */}
                <div className="text-gray-400 text-sm">{file.size}</div>

                {/* Date */}
                <div className="text-gray-400 text-sm">{formatDate(file.uploadDate)}</div>

                {/* Views */}
                <div className="text-gray-400 text-sm">{file.views}</div>

                {/* Actions */}
                <div className="flex items-center justify-center gap-2">
                  <button className="w-8 h-8 bg-white/5 border border-white/10 text-white rounded-lg hover:bg-white/10 transition-colors flex items-center justify-center">
                    <Download size={14} />
                  </button>
                  <button className="w-8 h-8 bg-white/5 border border-white/10 text-white rounded-lg hover:bg-white/10 transition-colors flex items-center justify-center">
                    <Edit2 size={14} />
                  </button>
                  <button
                    onClick={() => handleDelete(file.id)}
                    className="w-8 h-8 bg-white/5 border border-white/10 text-red-400 rounded-lg hover:bg-red-500/10 hover:border-red-500/30 transition-colors flex items-center justify-center"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Empty State */}
        {files.length === 0 && (
          <div className="bg-[#0A0A0A] border border-white/10 rounded-xl p-16 text-center">
            <div className="w-24 h-24 bg-gradient-to-br from-purple-500/20 to-blue-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
              <FileText size={48} className="text-purple-500" />
            </div>
            <h3 className="text-2xl font-bold text-white mb-3">No files yet</h3>
            <p className="text-gray-400 mb-6">Start uploading your academic resources to share with others</p>
            <button className="px-8 py-3 bg-gradient-to-r from-purple-500 to-blue-500 text-white rounded-xl font-semibold hover:scale-105 transition-transform inline-flex items-center gap-2">
              <Upload size={18} />
              Upload Your First File
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default MyFiles;