import { useState, useRef, useEffect, useCallback } from 'react';
import { Search, ZoomIn, ZoomOut, MapPin, Grid3x3, Upload, Move } from 'lucide-react';
import useFileStore from '../store/useFileStore';
import FileCard from '../components/canvas/FileCard';
import Sidebar from '../components/sidebar/Sidebar';
import MiniMap from '../components/canvas/MiniMap';

const BrowseFiles = () => {
  const { currentMode, setMode } = useFileStore();
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [searchQuery, setSearchQuery] = useState('');
  const [showMiniMap, setShowMiniMap] = useState(true);
  const canvasRef = useRef(null);
  const isDraggingRef = useRef(false);

  // Mock file data
  const [files, setFiles] = useState([
    {
      id: 1,
      name: 'Data Structures Assignment.pdf',
      type: 'pdf',
      category: 'Assignment',
      size: '2.4 MB',
      uploadedBy: 'John Doe',
      uploadDate: '2 days ago',
      position: { x: 100, y: 100 },
    },
    {
      id: 2,
      name: 'Algorithm Analysis Notes.docx',
      type: 'docx',
      category: 'Notes',
      size: '1.8 MB',
      uploadedBy: 'Jane Smith',
      uploadDate: '5 days ago',
      position: { x: 400, y: 150 },
    },
    {
      id: 3,
      name: 'Database Management Syllabus.pdf',
      type: 'pdf',
      category: 'Syllabus',
      size: '856 KB',
      uploadedBy: 'Mike Johnson',
      uploadDate: '1 week ago',
      position: { x: 700, y: 200 },
    },
    {
      id: 4,
      name: 'Web Development Question Paper.pdf',
      type: 'pdf',
      category: 'Question Paper',
      size: '1.2 MB',
      uploadedBy: 'Sarah Williams',
      uploadDate: '3 days ago',
      position: { x: 200, y: 400 },
    },
    {
      id: 5,
      name: 'Machine Learning Project.docx',
      type: 'docx',
      category: 'Assignment',
      size: '3.1 MB',
      uploadedBy: 'Alex Brown',
      uploadDate: '1 day ago',
      position: { x: 550, y: 450 },
    },
    {
      id: 6,
      name: 'Operating Systems Notes.pdf',
      type: 'pdf',
      category: 'Notes',
      size: '2.7 MB',
      uploadedBy: 'Emily Davis',
      uploadDate: '4 days ago',
      position: { x: 850, y: 500 },
    },
  ]);

  // Canvas panning
  const handleMouseDown = useCallback((e) => {
    if (currentMode === 'browse' && !e.target.closest('.file-card')) {
      e.preventDefault();
      setIsDragging(true);
      isDraggingRef.current = true;
      setDragStart({
        x: e.clientX - pan.x,
        y: e.clientY - pan.y,
      });
    }
  }, [currentMode, pan.x, pan.y]);

  const handleMouseMove = useCallback((e) => {
    if (isDraggingRef.current && currentMode === 'browse') {
      e.preventDefault();
      const newX = e.clientX - dragStart.x;
      const newY = e.clientY - dragStart.y;
      setPan({ x: newX, y: newY });
    }
  }, [currentMode, dragStart.x, dragStart.y]);

  const handleMouseUp = useCallback(() => {
    setIsDragging(false);
    isDraggingRef.current = false;
  }, []);

  // Zoom controls
  const handleZoomIn = () => setZoom((prev) => Math.min(prev + 0.1, 2));
  const handleZoomOut = () => setZoom((prev) => Math.max(prev - 0.1, 0.5));
  const handleResetView = () => {
    setZoom(1);
    setPan({ x: 0, y: 0 });
  };

  // File position update
  const handleFilePositionUpdate = (fileId, newPosition) => {
    setFiles((prevFiles) =>
      prevFiles.map((file) =>
        file.id === fileId ? { ...file, position: newPosition } : file
      )
    );
  };

  // Global mouse events
  useEffect(() => {
    const handleGlobalMouseMove = (e) => {
      if (isDraggingRef.current && currentMode === 'browse') {
        e.preventDefault();
        const newX = e.clientX - dragStart.x;
        const newY = e.clientY - dragStart.y;
        setPan({ x: newX, y: newY });
      }
    };

    const handleGlobalMouseUp = () => {
      setIsDragging(false);
      isDraggingRef.current = false;
    };

    if (isDragging) {
      window.addEventListener('mousemove', handleGlobalMouseMove);
      window.addEventListener('mouseup', handleGlobalMouseUp);
    }

    return () => {
      window.removeEventListener('mousemove', handleGlobalMouseMove);
      window.removeEventListener('mouseup', handleGlobalMouseUp);
    };
  }, [isDragging, dragStart.x, dragStart.y, currentMode]);

  return (
    <div className="min-h-screen bg-black pt-16">
      {/* Floating Sidebar */}
      <Sidebar />

      {/* Top Control Bar - Fixed below navbar */}
      <div className="fixed top-16 left-0 right-0 h-16 bg-[#0A0A0A]/80 backdrop-blur-md border-b border-white/10 flex items-center justify-between px-8 z-[95] gap-4">
        {/* Search Bar */}
        <div className="relative flex-1 max-w-4xl">
          <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-600" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search files, assignments, papers..."
            className="w-full h-10 pl-12 pr-4 bg-[#1A1A1A] border border-white/10 rounded-full text-white text-sm placeholder:text-gray-600 focus:border-purple-500 focus:outline-none transition-colors"
          />
        </div>

        {/* View Controls */}
        <div className="flex items-center gap-3 flex-shrink-0">
          {/* Zoom Controls */}
          <div className="flex items-center gap-2 bg-[#1A1A1A] border border-white/10 rounded-lg p-1">
            <button
              onClick={handleZoomOut}
              className="w-9 h-9 flex items-center justify-center text-white hover:bg-white/10 rounded transition-colors"
              title="Zoom Out"
            >
              <ZoomOut size={18} />
            </button>
            <div className="w-16 text-center text-sm text-gray-400 font-medium">
              {Math.round(zoom * 100)}%
            </div>
            <button
              onClick={handleZoomIn}
              className="w-9 h-9 flex items-center justify-center text-white hover:bg-white/10 rounded transition-colors"
              title="Zoom In"
            >
              <ZoomIn size={18} />
            </button>
          </div>

          {/* Reset View */}
          <button
            onClick={handleResetView}
            className="px-4 h-9 bg-[#1A1A1A] border border-white/10 rounded-lg text-white text-sm font-medium hover:bg-white/5 transition-colors"
          >
            Reset View
          </button>

          {/* Mini Map Toggle */}
          <button
            onClick={() => setShowMiniMap(!showMiniMap)}
            className={`w-9 h-9 flex items-center justify-center border rounded-lg transition-colors ${
              showMiniMap
                ? 'bg-purple-500 border-purple-500 text-white'
                : 'bg-[#1A1A1A] border-white/10 text-white hover:bg-white/5'
            }`}
            title="Toggle Mini Map"
          >
            <MapPin size={18} />
          </button>
        </div>
      </div>

      {/* Canvas Container - with top padding to account for fixed bars */}
      <div
        ref={canvasRef}
        onMouseDown={handleMouseDown}
        className={`h-[calc(100vh-8rem)] relative overflow-hidden select-none ${
          isDragging && currentMode === 'browse' ? 'cursor-grabbing' : 'cursor-grab'
        }`}
        style={{
          backgroundImage: `
            radial-gradient(circle, rgba(255,255,255,0.15) 1.5px, transparent 1.5px)
          `,
          backgroundSize: `${30 * zoom}px ${30 * zoom}px`,
          backgroundPosition: `${pan.x}px ${pan.y}px`,
        }}
      >
        {/* File Cards */}
        <div
          style={{
            transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
            transformOrigin: '0 0',
            willChange: isDragging ? 'transform' : 'auto',
          }}
          className="absolute inset-0"
        >
          {files.map((file) => (
            <FileCard
              key={file.id}
              file={file}
              mode={currentMode}
              zoom={zoom}
              onPositionUpdate={handleFilePositionUpdate}
            />
          ))}
        </div>

        {/* Mode Indicator */}
        <div className="absolute top-4 left-1/2 -translate-x-1/2 px-6 py-3 bg-[#0A0A0A]/90 backdrop-blur-md border border-white/10 rounded-full flex items-center gap-3 pointer-events-none z-10">
          {currentMode === 'browse' && (
            <>
              <Grid3x3 size={18} className="text-purple-500" />
              <span className="text-white font-medium">Browse Mode</span>
            </>
          )}
          {currentMode === 'upload' && (
            <>
              <Upload size={18} className="text-blue-500" />
              <span className="text-white font-medium">Upload Mode</span>
            </>
          )}
          {currentMode === 'organize' && (
            <>
              <Move size={18} className="text-green-500" />
              <span className="text-white font-medium">Organize Mode</span>
            </>
          )}
        </div>

        {/* Upload Dropzone */}
        {currentMode === 'upload' && (
          <div className="absolute inset-8 border-2 border-dashed border-purple-500/50 rounded-2xl flex items-center justify-center bg-purple-500/5 backdrop-blur-sm pointer-events-none z-10">
            <div className="text-center">
              <div className="w-24 h-24 mx-auto mb-4 bg-gradient-to-br from-purple-500 to-blue-500 rounded-full flex items-center justify-center">
                <Upload size={48} className="text-white" />
              </div>
              <h3 className="text-2xl font-bold text-white mb-2">Drop files anywhere</h3>
              <p className="text-gray-400">or click to browse</p>
              <p className="text-sm text-gray-500 mt-2">Supports PDF and DOCX files</p>
            </div>
          </div>
        )}
      </div>

      {/* Mini Map */}
      {showMiniMap && (
        <MiniMap 
          files={files} 
          viewportPan={pan} 
          viewportZoom={zoom} 
          canvasSize={{ width: 2000, height: 1500 }} 
        />
      )}
    </div>
  );
};

export default BrowseFiles;