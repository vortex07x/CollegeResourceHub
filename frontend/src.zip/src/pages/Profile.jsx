import { useState } from 'react';
import { User, Mail, Calendar, Save, Eye, FileText, Award, X } from 'lucide-react';

const Profile = () => {
  const [isEditing, setIsEditing] = useState(false);
  const [showAvatarPicker, setShowAvatarPicker] = useState(false);
  const [avatarConfig, setAvatarConfig] = useState({
    style: 'avataaars',
    seed: 'John-Doe-1'
  });
  const [formData, setFormData] = useState({
    name: 'John Doe',
    email: 'john.doe@college.edu',
    bio: 'Computer Science student passionate about sharing knowledge.',
    joinDate: 'January 2024',
  });
  const [successMessage, setSuccessMessage] = useState('');

  // Avatar styles and seeds for variations
  const avatarStyles = [
    { name: 'Avataaars', value: 'avataaars' },
    { name: 'Personas', value: 'personas' },
    { name: 'Lorelei', value: 'lorelei' },
    { name: 'Notionists', value: 'notionists' },
    { name: 'Adventurer', value: 'adventurer' },
    { name: 'Big Ears', value: 'big-ears' },
    { name: 'Bottts', value: 'bottts' },
    { name: 'Shapes', value: 'shapes' },
  ];

  const seeds = [
    'Happy', 'Cool', 'Smart', 'Creative', 'Friendly', 'Wise',
    'Bold', 'Clever', 'Bright', 'Brave', 'Kind', 'Swift',
    'Sharp', 'Noble', 'Gentle', 'Strong', 'Quick', 'Calm'
  ];

  const stats = [
    { icon: FileText, label: 'Files Uploaded', value: 24, color: 'text-purple-500' },
    { icon: Eye, label: 'Total Views', value: 1247, color: 'text-blue-500' },
    { icon: Award, label: 'Contributions', value: 38, color: 'text-green-500' },
  ];

  // Generate avatar URL
  const getAvatarUrl = (style, seed) => {
    return `https://api.dicebear.com/7.x/${style}/svg?seed=${seed}`;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSaveProfile = (e) => {
    e.preventDefault();
    setIsEditing(false);
    setSuccessMessage('Profile updated successfully!');
    setTimeout(() => setSuccessMessage(''), 3000);
  };

  const handleAvatarSelect = (style, seed) => {
    setAvatarConfig({ style, seed });
    setShowAvatarPicker(false);
    setSuccessMessage('Avatar updated successfully!');
    setTimeout(() => setSuccessMessage(''), 3000);
  };

  return (
    <div className="min-h-screen bg-black pt-20 px-8 pb-16">
      <div className="max-w-5xl mx-auto">
        {/* Success Message */}
        {successMessage && (
          <div className="mb-6 p-4 bg-green-500/10 border border-green-500/30 rounded-xl text-green-500 text-sm flex items-center gap-2">
            <span>✓</span>
            <span>{successMessage}</span>
          </div>
        )}

        {/* Profile Header */}
        <div className="bg-gradient-to-r from-purple-500 to-blue-500 rounded-2xl p-12 mb-8 relative overflow-hidden">
          <div className="relative z-10 flex flex-col md:flex-row gap-8 items-center">
            {/* Avatar */}
            <div className="relative group">
              <div className="w-32 h-32 rounded-full border-4 border-white/30 bg-white overflow-hidden">
                <img 
                  src={getAvatarUrl(avatarConfig.style, avatarConfig.seed)} 
                  alt="Profile Avatar"
                  className="w-full h-full object-cover"
                />
              </div>
              <button
                onClick={() => setShowAvatarPicker(true)}
                className="absolute bottom-0 right-0 w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-lg hover:scale-110 transition-transform"
                title="Change Avatar"
              >
                <Eye size={18} className="text-purple-500" />
              </button>
            </div>

            {/* User Info */}
            <div className="flex-1 text-center md:text-left">
              <h1 className="text-4xl font-bold text-white mb-2">{formData.name}</h1>
              <p className="text-white/80 mb-1">{formData.email}</p>
              <div className="flex items-center gap-2 text-white/60 text-sm justify-center md:justify-start">
                <Calendar size={16} />
                <span>Member since {formData.joinDate}</span>
              </div>
            </div>
          </div>

          {/* Decorative Circles */}
          <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl"></div>
          <div className="absolute bottom-0 left-0 w-64 h-64 bg-white/10 rounded-full translate-y-1/2 -translate-x-1/2 blur-3xl"></div>
        </div>

        {/* Avatar Picker Modal */}
        {showAvatarPicker && (
          <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50 px-4">
            <div className="bg-[#0A0A0A] border border-white/10 rounded-2xl p-8 max-w-4xl w-full max-h-[90vh] overflow-y-auto relative">
              {/* Close Button */}
              <button
                onClick={() => setShowAvatarPicker(false)}
                className="absolute top-4 right-4 w-8 h-8 flex items-center justify-center text-gray-400 hover:text-white hover:bg-white/5 rounded-lg transition-colors"
              >
                <X size={20} />
              </button>

              <h3 className="text-2xl font-bold text-white mb-2">Choose Your Avatar</h3>
              <p className="text-sm text-gray-400 mb-6">Select a style and variation</p>
              
              {/* Avatar Style Selector */}
              <div className="mb-6">
                <h4 className="text-sm font-semibold text-gray-400 mb-3">Avatar Style</h4>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {avatarStyles.map((style) => (
                    <button
                      key={style.value}
                      onClick={() => setAvatarConfig({ ...avatarConfig, style: style.value })}
                      className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                        avatarConfig.style === style.value
                          ? 'bg-gradient-to-r from-purple-500 to-blue-500 text-white'
                          : 'bg-[#1A1A1A] text-gray-400 hover:bg-[#2A2A2A]'
                      }`}
                    >
                      {style.name}
                    </button>
                  ))}
                </div>
              </div>

              {/* Avatar Variations Grid */}
              <div>
                <h4 className="text-sm font-semibold text-gray-400 mb-3">Choose Variation</h4>
                <div className="grid grid-cols-4 md:grid-cols-6 gap-4">
                  {seeds.map((seed, index) => (
                    <button
                      key={index}
                      onClick={() => handleAvatarSelect(avatarConfig.style, seed)}
                      className={`aspect-square rounded-xl overflow-hidden border-2 transition-all hover:scale-105 ${
                        avatarConfig.seed === seed && avatarConfig.style === avatarConfig.style
                          ? 'border-purple-500 ring-4 ring-purple-500/30'
                          : 'border-white/10 hover:border-purple-500/50'
                      }`}
                    >
                      <img 
                        src={getAvatarUrl(avatarConfig.style, seed)} 
                        alt={`Avatar ${seed}`}
                        className="w-full h-full object-cover bg-white"
                      />
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Statistics Section */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {stats.map((stat, index) => (
            <div
              key={index}
              className="bg-[#0A0A0A] border border-white/10 rounded-xl p-6 text-center"
            >
              <stat.icon size={32} className={`${stat.color} mx-auto mb-3`} />
              <div className="text-4xl font-bold text-white mb-2">{stat.value}</div>
              <div className="text-sm text-gray-400">{stat.label}</div>
            </div>
          ))}
        </div>

        {/* Account Information Section */}
        <div className="bg-[#0A0A0A] border border-white/10 rounded-xl p-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-white">Account Information</h2>
            {!isEditing ? (
              <button
                onClick={() => setIsEditing(true)}
                className="px-6 py-2 bg-gradient-to-r from-purple-500 to-blue-500 text-white rounded-lg font-semibold hover:opacity-90 transition-opacity"
              >
                Edit Profile
              </button>
            ) : (
              <div className="flex gap-2">
                <button
                  onClick={() => setIsEditing(false)}
                  className="px-6 py-2 bg-white/5 border border-white/10 text-white rounded-lg font-semibold hover:bg-white/10 transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSaveProfile}
                  className="px-6 py-2 bg-gradient-to-r from-purple-500 to-blue-500 text-white rounded-lg font-semibold hover:opacity-90 transition-opacity flex items-center gap-2"
                >
                  <Save size={18} />
                  Save Changes
                </button>
              </div>
            )}
          </div>

          <form className="space-y-5">
            {/* Name */}
            <div>
              <label className="block text-sm font-medium text-gray-400 mb-2">Full Name</label>
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
                disabled={!isEditing}
                className="w-full h-12 px-4 bg-[#1A1A1A] border border-white/10 rounded-lg text-white text-sm focus:border-purple-500 focus:outline-none transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              />
            </div>

            {/* Email */}
            <div>
              <label className="block text-sm font-medium text-gray-400 mb-2">Email Address</label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                disabled={!isEditing}
                className="w-full h-12 px-4 bg-[#1A1A1A] border border-white/10 rounded-lg text-white text-sm focus:border-purple-500 focus:outline-none transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              />
            </div>

            {/* Bio */}
            <div>
              <label className="block text-sm font-medium text-gray-400 mb-2">Bio</label>
              <textarea
                name="bio"
                value={formData.bio}
                onChange={handleChange}
                disabled={!isEditing}
                rows={4}
                className="w-full px-4 py-3 bg-[#1A1A1A] border border-white/10 rounded-lg text-white text-sm focus:border-purple-500 focus:outline-none transition-colors disabled:opacity-50 disabled:cursor-not-allowed resize-none"
              />
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Profile;